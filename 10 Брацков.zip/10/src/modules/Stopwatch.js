
function Stopwatch() {};

export { Stopwatch };
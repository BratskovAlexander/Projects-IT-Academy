

function Timer() {};

export { Timer };